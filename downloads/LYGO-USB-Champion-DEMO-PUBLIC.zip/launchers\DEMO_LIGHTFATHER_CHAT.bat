@echo off
setlocal
cd /d "%~dp0.."
set /p MSG=Ask Lightfather (demo): 
if "%MSG%"=="" set MSG=Explain this LYGO USB demo in plain language.
python scripts\demo_lightfather_chat.py "%MSG%"
pause