#!/usr/bin/env python3
"""Verify Ollama + model weights on USB (standalone gate)."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path


def key_root() -> Path:
    env = os.environ.get("LYGO_BUILDER_KEY_ROOT")
    if env:
        return Path(env)
    return Path(__file__).resolve().parents[1]


def model_dir(key: Path) -> Path:
    return key / "product" / "models" / "ollama"


def dir_has_weights(root: Path) -> bool:
    if not root.is_dir():
        return False
    # Ollama stores blobs under manifests/ and models/
    for sub in ("manifests", "blobs"):
        p = root / sub
        if p.is_dir() and any(p.iterdir()):
            return True
    # fallback: any file > 1MB under tree
    for f in root.rglob("*"):
        if f.is_file() and f.stat().st_size > 1_000_000:
            return True
    return False


def _ollama_on_path() -> bool:
    cmd = ["where", "ollama"] if sys.platform == "win32" else ["which", "ollama"]
    return subprocess.run(cmd, capture_output=True).returncode == 0


def ollama_list(model_name: str) -> bool:
    env = os.environ.copy()
    env.setdefault("OLLAMA_MODELS", str(model_dir(key_root())))
    try:
        cp = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
            timeout=60,
            env=env,
        )
    except FileNotFoundError:
        return False
    if cp.returncode != 0:
        return False
    return model_name.split(":")[0] in cp.stdout or model_name in cp.stdout


def main() -> int:
    key = key_root()
    manifest_path = key / "product" / "models" / "MODEL_MANIFEST.json"
    if not manifest_path.is_file():
        print(json.dumps({"ok": False, "error": "missing MODEL_MANIFEST.json"}))
        return 1
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    name = manifest.get("primary", {}).get("name", "qwen2.5:3b")
    mdir = model_dir(key)
    os.environ.setdefault("OLLAMA_MODELS", str(mdir))
    portable = key / "product" / "runtime" / "ollama" / "ollama.exe"
    report = {
        "ok": False,
        "profile": manifest.get("standalone_profile", "SOVEREIGN_FAST"),
        "model": name,
        "usb_models_dir": str(mdir),
        "portable_ollama_on_usb": portable.is_file(),
        "weights_on_usb": dir_has_weights(mdir),
        "ollama_on_path": _ollama_on_path(),
        "ollama_lists_model": ollama_list(name),
    }
    # Standalone travel requires weights under product/models/ollama
    report["ok"] = report["weights_on_usb"] and report["ollama_on_path"]
    out = key / "verify" / "standalone_last_run.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())