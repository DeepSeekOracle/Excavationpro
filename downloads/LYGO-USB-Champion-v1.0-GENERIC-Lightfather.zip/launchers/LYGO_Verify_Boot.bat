@echo off
title LYGO BUILDR USB Verify
cd /d "%~dp0.."
set LYGO_BUILDER_KEY_ROOT=%CD%
set LYGO_STACK_ROOT=%CD%\stack\lygo-protocol-stack
python verify_bootstrap.py --edition GROK_BUILDR
pause