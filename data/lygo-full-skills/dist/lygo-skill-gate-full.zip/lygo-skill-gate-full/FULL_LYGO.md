# FULL LYGO package — lygo-skill-gate

Channel: **FULL_LYGO_ENGINEER** (not ClawHub public safety surface).

For a **self-auditing LYGO lattice**. Integrity comes from the lattice
(P0, dual ledgers, eggs, sentinel, human consent for live writes) —
not from corporate gutted shells alone.

Steward: Justin Helmer / Excavationpro (Lightfather)
Source: `D:\lygo-protocol-stack\docs\skills\lygo-skill-gate`
Packaged: 2026-08-08T05:16:34.508185+00:00
Files: 7

Good faith · LYGO policy · engineer autonomy · not malicious by design.
You are responsible for extended systems you run.
