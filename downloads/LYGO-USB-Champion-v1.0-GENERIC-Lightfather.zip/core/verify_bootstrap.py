#!/usr/bin/env python3
"""LYGO BUILDR USB — bootstrap & integrity gate (Phase 1 + Phase 2)."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

KEY = Path(__file__).resolve().parent
HERMES = KEY / "hermes"
sys.path.insert(0, str(KEY / "phase2"))
sys.path.insert(0, str(HERMES))
import lygo_hermes_audit as hermes  # noqa: E402

MANIFEST = KEY / "BUILDER_MANIFEST.json"
STACK = KEY / "stack" / "lygo-protocol-stack"


def check_manifest() -> dict:
    if not MANIFEST.is_file():
        return {"ok": False, "error": "missing BUILDER_MANIFEST.json"}
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    return {"ok": True, "signature": data.get("signature"), "phase": data.get("phase", 1)}


def check_stack() -> dict:
    if not STACK.is_dir():
        return {"ok": False, "error": "missing stack/lygo-protocol-stack"}
    markers = [
        STACK / "tools" / "verify_kernel_eggs.py",
        STACK / "tools" / "verify_lattice_alignment.py",
    ]
    missing = [str(m.relative_to(STACK)) for m in markers if not m.is_file()]
    return {"ok": not missing, "missing": missing}


def check_hermes() -> dict:
    log = KEY / "data" / "hermes_audit" / "audit_trail.log"
    if not log.parent.is_dir():
        log = KEY / "hermes" / "audit_trail.log"
    hermes.set_log_path(log)
    hermes.log_event("bootstrap_start", actor="verify_bootstrap")
    result = hermes.validate_audit_chain()
    hermes.log_event("bootstrap_hermes_ok" if result.get("valid") else "bootstrap_hermes_fail", detail=result)
    return {"ok": result.get("valid", False), **result}


def check_eggs_light() -> dict:
    script = STACK / "tools" / "verify_kernel_eggs.py"
    if not script.is_file():
        return {"ok": True, "skipped": "no stack"}
    cp = subprocess.run(
        [sys.executable, str(script)],
        cwd=str(STACK),
        capture_output=True,
        text=True,
        timeout=120,
    )
    return {"ok": cp.returncode == 0, "exit_code": cp.returncode, "stdout": (cp.stdout or "")[-800:]}


def check_phase2() -> dict:
    init = subprocess.run(
        [sys.executable, str(KEY / "phase2" / "init_data_partition.py"), "--key-root", str(KEY)],
        capture_output=True,
        text=True,
        timeout=60,
    )
    mount = subprocess.run(
        [sys.executable, str(KEY / "phase2" / "mount_core.py"), "--key-root", str(KEY)],
        capture_output=True,
        text=True,
        timeout=180,
    )
    try:
        mount_json = json.loads(mount.stdout or "{}")
    except json.JSONDecodeError:
        mount_json = {"ok": False, "raw": (mount.stdout or "")[-500:]}
    core_ok = (KEY / "images" / "lygo_core.tar.gz").is_file()
    return {
        "ok": init.returncode == 0 and mount_json.get("ok", False),
        "data_init": init.returncode == 0,
        "core_image_present": core_ok,
        "mount": mount_json,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--edition", default="GROK_BUILDR")
    ap.add_argument("--phase2", action="store_true", help="Require signed core + data partition")
    ap.add_argument("--daemon", action="store_true")
    args = ap.parse_args()

    print(f"LYGO BUILDR USB bootstrap — edition={args.edition} phase2={args.phase2}")
    steps = {
        "manifest": check_manifest(),
        "stack": check_stack(),
        "hermes": check_hermes(),
        "kernel_eggs": check_eggs_light(),
    }
    if args.phase2:
        steps["phase2"] = check_phase2()
    all_ok = all(s.get("ok") for s in steps.values())
    report = {
        "edition": args.edition,
        "phase2": args.phase2,
        "key_root": str(KEY),
        "steps": steps,
        "all_ok": all_ok,
    }
    out = KEY / "verify" / "bootstrap_last_run.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if args.daemon:
        subprocess.run(
            [sys.executable, str(KEY / "phase2" / "daemon_supervisor.py"), "--key-root", str(KEY)],
            cwd=str(KEY),
        )
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())