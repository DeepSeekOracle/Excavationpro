@echo off
title LYGO USB One-Boot AI
cd /d "%~dp0.."
powershell -ExecutionPolicy Bypass -File scripts\bootstrap_env.ps1
if not exist "product\runtime\ollama\ollama.exe" (
  echo Portable Ollama not on stick yet. Bundling from this PC once...
  powershell -ExecutionPolicy Bypass -File scripts\bundle_ollama_to_usb.ps1
  if errorlevel 1 pause & exit /b 1
  powershell -ExecutionPolicy Bypass -File scripts\bootstrap_env.ps1
)
if not exist "product\models\ollama\blobs" (
  echo Model not on stick. Online once for hydrate...
  powershell -ExecutionPolicy Bypass -File scripts\hydrate_usb_models.ps1
  if errorlevel 1 pause & exit /b 1
)
powershell -ExecutionPolicy Bypass -File scripts\ensure_ollama_serve.ps1
python scripts\verify_standalone_usb.py
if errorlevel 1 pause & exit /b 1
for /f "tokens=*" %%M in ('powershell -NoProfile -Command "(Get-Content product\models\MODEL_MANIFEST.json | ConvertFrom-Json).primary.name"') do set MODEL=%%M
echo One-boot ready: %%MODEL%% on USB.
"%~dp0..\product\runtime\ollama\ollama.exe" run %MODEL%
pause