#!/usr/bin/env python3
"""Scan PUBLIC_V1_GENERIC export — no secrets, no Ollama runtime, no model weights."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

MAX_FILE_MB = 48
FORBIDDEN_PATH_FRAGMENTS = (
    "product/runtime/ollama",
    "_builder_vault",
)


def scan_v1(root: Path) -> dict:
    hits: list[str] = []
    missing: list[str] = []

    sku_py = Path(__file__).resolve().parent / "verify_public_sku.py"
    if sku_py.is_file():
        proc = subprocess.run(
            [sys.executable, str(sku_py), str(root)],
            capture_output=True,
            text=True,
            timeout=300,
        )
        try:
            base = json.loads(proc.stdout)
        except json.JSONDecodeError:
            base = {"ok": False, "hits": ["sku_scan_failed"], "missing": []}
    else:
        base = {"ok": True, "hits": [], "missing": []}
    hits.extend(base.get("hits") or [])

    manifest_path = root / "PUBLIC_MANIFEST.json"
    edition_ok = False
    if manifest_path.is_file():
        try:
            mj = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
            edition_ok = mj.get("edition") == "PUBLIC_V1_GENERIC"
        except json.JSONDecodeError:
            hits.append("bad_manifest_json")
    else:
        missing.append("PUBLIC_MANIFEST.json")

    for extra in (
        "BUILD_SELF_FIRST_USE.txt",
        "config/USB_CHAMPIONS_CORE.json",
        "champions/Lightfather/system_prompt.txt",
        "scripts/usb_champions_core.py",
    ):
        if not (root / extra).exists():
            missing.append(extra)

    for f in root.rglob("*"):
        if not f.is_file():
            continue
        rel = f.relative_to(root).as_posix()
        if any(x in rel for x in FORBIDDEN_PATH_FRAGMENTS):
            hits.append(f"forbidden_path:{rel}")
        if "product/models/ollama" in rel.replace("\\", "/"):
            if f.name not in ("MODEL_MANIFEST.json", "STANDALONE_MODEL_DESIGN.md", ".gitkeep"):
                if f.stat().st_size > 4096:
                    hits.append(f"weight_or_blob:{rel}")
        if f.stat().st_size > MAX_FILE_MB * 1024 * 1024:
            hits.append(f"oversize:{rel}")

    ok = base.get("ok") and edition_ok and not hits and not missing
    return {
        "ok": ok,
        "edition": "PUBLIC_V1_GENERIC",
        "root": str(root),
        "hits": hits[:50],
        "missing": missing,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("export_dir")
    args = ap.parse_args()
    report = scan_v1(Path(args.export_dir))
    print(json.dumps(report, indent=2))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())