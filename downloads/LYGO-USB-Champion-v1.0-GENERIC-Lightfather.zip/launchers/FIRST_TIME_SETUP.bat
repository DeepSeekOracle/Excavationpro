@echo off
title LYGO USB - First Time Setup (online once)
cd /d "%~dp0.."
echo This downloads Ollama runtime + AI model onto the USB (~8 GB). Needs internet.
pause
powershell -ExecutionPolicy Bypass -File scripts\install_usb_runtime.ps1
if not exist "product\runtime\ollama\ollama.exe" (
  powershell -ExecutionPolicy Bypass -File scripts\bundle_ollama_to_usb.ps1
)
powershell -ExecutionPolicy Bypass -File scripts\hydrate_usb_models.ps1
if errorlevel 1 (
  echo Setup failed. See PUBLIC_QUICKSTART.txt
  pause
  exit /b 1
)
echo Setup complete. Use LYGO_One_Boot_AI.bat
pause