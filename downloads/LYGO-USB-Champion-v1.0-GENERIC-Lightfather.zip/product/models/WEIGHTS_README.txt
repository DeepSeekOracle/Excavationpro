Weights not included in v1.0 GENERIC. Use PC Ollama or scripts\hydrate_usb_models.ps1.
