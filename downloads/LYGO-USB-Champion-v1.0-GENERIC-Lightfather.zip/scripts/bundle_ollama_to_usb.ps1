# Copy Ollama Windows runtime onto USB (~5 GB one-time on builder machine)
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "bootstrap_env.ps1")
$Key = $env:LYGO_BUILDER_KEY_ROOT
$src = Join-Path $env:LOCALAPPDATA "Programs\Ollama"
$dst = Join-Path $Key "product\runtime\ollama"
if (-not (Test-Path (Join-Path $src "ollama.exe"))) {
    Write-Host "Host Ollama not found. Install from https://ollama.com then re-run."
    exit 1
}
New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
Write-Host "Bundling Ollama: $src -> $dst (excludes uninstaller)"
robocopy $src $dst /E /XF "unins000.dat" "unins000.exe" "unins000.msg" "ollama app.exe" /NFL /NDL /NJH /NJS | Out-Null
if (-not (Test-Path (Join-Path $dst "ollama.exe"))) { exit 1 }
$ver = & (Join-Path $dst "ollama.exe") --version 2>&1
@{
    bundled_utc = (Get-Date).ToUniversalTime().ToString("o")
    source      = $src
    dest        = $dst
    version     = "$ver"
} | ConvertTo-Json | Set-Content (Join-Path $dst "LYGO_BUNDLE.json") -Encoding utf8
Write-Host "OK portable Ollama on USB: $dst"