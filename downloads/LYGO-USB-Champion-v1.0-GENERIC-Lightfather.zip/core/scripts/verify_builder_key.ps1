$ErrorActionPreference = "Continue"
$Key = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
. (Join-Path $Key "scripts\bootstrap_env.ps1")
python tools/verify_lattice_alignment.py
python tools/verify_champion_consolidation.py
python tools/run_parity_tests.py
Write-Host "Compare verify/*.json and BUILDER_MANIFEST.json github SHAs with git ls-remote"
