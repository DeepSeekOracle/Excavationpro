#!/usr/bin/env python3
"""PUBLIC_DEMO — one Lightfather chat turn via local Ollama only (127.0.0.1)."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

try:
    import urllib.request
except ImportError:
    raise SystemExit("Python urllib required")

ROOT = Path(__file__).resolve().parents[1]
PROMPT = ROOT / "champions" / "Lightfather" / "system_prompt.txt"
HOST = "http://127.0.0.1:11434"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("prompt", nargs="?", default="In 3 bullets, what is this USB demo and what is locked?")
    ap.add_argument("--model", default="llama3.2:1b")
    args = ap.parse_args()
    if not PROMPT.is_file():
        print(json.dumps({"ok": False, "error": "missing system_prompt"}))
        return 1
    system = PROMPT.read_text(encoding="utf-8")
    body = json.dumps(
        {
            "model": args.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": args.prompt[:4000]},
            ],
            "stream": False,
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        f"{HOST}/api/chat",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=180) as resp:
            data = json.loads(resp.read().decode())
        print(data.get("message", {}).get("content", ""))
        return 0
    except Exception as exc:  # noqa: BLE001
        print(
            json.dumps(
                {
                    "ok": False,
                    "error": str(exc),
                    "hint": "Install Ollama, run: ollama pull llama3.2:1b",
                },
                indent=2,
            )
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())