﻿LYGO USB Champion v1.0 GENERIC â€” Lightfather (free public edition)
==================================================================
Edition: PUBLIC_V1_GENERIC | Pairs with LYGO-Claw 1.0
READ FIRST: BUILD_SELF_FIRST_USE.txt

This kit is FULL LYGO USB champion software without portable Ollama or model
weights (small download). Use PC Ollama or run hydrate/bundle scripts when ready.

Quick: launchers\CHECK_SYSTEM.bat -> ollama pull qwen2.5:3b -> LYGO_One_Boot_AI.bat
Verify: launchers\LYGO_Verify_Phase2.bat
