param(
    [ValidateSet("SOVEREIGN_FAST", "SPEED")]
    [string]$Profile = "SOVEREIGN_FAST"
)
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "bootstrap_env.ps1")
$Key = $env:LYGO_BUILDER_KEY_ROOT
$manifestPath = Join-Path $Key "product\models\MODEL_MANIFEST.json"
$j = Get-Content $manifestPath -Raw | ConvertFrom-Json

. (Join-Path $PSScriptRoot "resolve_ollama.ps1") -Quiet
if (-not $env:LYGO_OLLAMA_EXE) {
    Write-Host "Run scripts\bundle_ollama_to_usb.ps1 or install_usb_runtime.ps1 first"
    exit 1
}

$tag = if ($Profile -eq "SPEED" -and $j.speed_optional.name) { $j.speed_optional.name } else { $j.primary.name }

powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "ensure_ollama_serve.ps1")
Write-Host ">> pull $tag (OLLAMA_MODELS=$env:OLLAMA_MODELS)"
& $env:LYGO_OLLAMA_EXE pull $tag
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$usbModels = $env:OLLAMA_MODELS
$defaultModels = Join-Path $env:USERPROFILE ".ollama\models"
$hasUsbBlobs = Test-Path (Join-Path $usbModels "blobs")
if (-not $hasUsbBlobs -and (Test-Path $defaultModels)) {
    Write-Host "Syncing model blobs to USB from default store..."
    New-Item -ItemType Directory -Force -Path $usbModels | Out-Null
    robocopy $defaultModels $usbModels /E /NFL /NDL /NJH /NJS | Out-Null
}

python (Join-Path $Key "scripts\verify_standalone_usb.py")
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "USB standalone model ready on stick."