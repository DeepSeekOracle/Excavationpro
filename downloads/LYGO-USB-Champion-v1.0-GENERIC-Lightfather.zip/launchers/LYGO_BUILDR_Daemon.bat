@echo off
title LYGO BUILDR USB Daemon :9630
cd /d "%~dp0.."
set LYGO_BUILDER_KEY_ROOT=%CD%
set LYGO_STACK_ROOT=%CD%\stack\lygo-protocol-stack
powershell -ExecutionPolicy Bypass -File scripts\bootstrap_env.ps1
python phase2\init_data_partition.py
echo Starting BUILDR daemon (supervisor + task queue). Ctrl+C to stop.
python phase2\buildr_usb_daemon.py --key-root %CD% --with-ollama
pause