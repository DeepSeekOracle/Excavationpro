# LYGO BUILDR Daemon Tray - starts daemon + system tray menu (Windows 10/11)
param([switch]$WithOllama)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$resolveScript = Join-Path (Split-Path $ScriptDir -Parent) "scripts\resolve_usb_root.ps1"
if (-not (Test-Path $resolveScript)) {
    Write-Host "Missing resolve_usb_root.ps1"
    exit 1
}
$UsbRoot = & $resolveScript -ExtraSearchRoots @((Resolve-Path "$ScriptDir\..").Path)
if (-not $UsbRoot) {
    [System.Windows.Forms.MessageBox]::Show(
        "LYGO USB not found. Plug in the stick (LYGO_BUILDER_KEY) and try again.",
        "LYGO BUILDR",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
    exit 0
}

$startScript = Join-Path $UsbRoot "scripts\start_buildr_daemon.ps1"
$oneBootBat = Join-Path $UsbRoot "launchers\LYGO_One_Boot_AI.bat"
$daemonProc = $null
try {
    $daemonProc = & $startScript -KeyRoot $UsbRoot -WithOllama:$WithOllama
} catch {
    [System.Windows.Forms.MessageBox]::Show("Failed to start daemon: $_", "LYGO BUILDR") | Out-Null
    exit 1
}

$icon = [System.Drawing.SystemIcons]::Shield
$tray = New-Object System.Windows.Forms.NotifyIcon
$tray.Icon = $icon
$tray.Text = "LYGO BUILDR Daemon (127.0.0.1:9630)"
$tray.Visible = $true

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$tray.ContextMenuStrip = $menu

$openHealth = New-Object System.Windows.Forms.ToolStripMenuItem
$openHealth.Text = "Open daemon health (browser)"
$openHealth.Add_Click({ Start-Process "http://127.0.0.1:9630/health" })
[void]$menu.Items.Add($openHealth)

$openChat = New-Object System.Windows.Forms.ToolStripMenuItem
$openChat.Text = "Open LYGO AI Chat (One-Boot)"
$openChat.Add_Click({
    if (Test-Path $oneBootBat) { Start-Process -FilePath $oneBootBat -WorkingDirectory $UsbRoot }
})
[void]$menu.Items.Add($openChat)

$openClaw = New-Object System.Windows.Forms.ToolStripMenuItem
$openClaw.Text = "LYGO-Claw docs (web)"
$openClaw.Add_Click({ Start-Process "https://deepseekoracle.github.io/lygo-protocol-stack/LYGO_CLAW.html" })
[void]$menu.Items.Add($openClaw)

[void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))

$stopDaemon = New-Object System.Windows.Forms.ToolStripMenuItem
$stopDaemon.Text = "Stop daemon"
$stopDaemon.Add_Click({
    if ($daemonProc -and -not $daemonProc.HasExited) {
        $daemonProc.Kill()
        $daemonProc.Dispose()
    }
    $pidFile = Join-Path $UsbRoot "data\user_data\buildr_daemon.pid"
    if (Test-Path $pidFile) { Remove-Item $pidFile -Force -ErrorAction SilentlyContinue }
    $tray.ShowBalloonTip(3000, "LYGO BUILDR", "Daemon stopped.", [System.Windows.Forms.ToolTipIcon]::Info)
})
[void]$menu.Items.Add($stopDaemon)

$exitTray = New-Object System.Windows.Forms.ToolStripMenuItem
$exitTray.Text = "Exit tray (daemon keeps running)"
$exitTray.Add_Click({
    $tray.Visible = $false
    $tray.Dispose()
    [System.Windows.Forms.Application]::Exit()
})
[void]$menu.Items.Add($exitTray)

$tray.Add_DoubleClick({ Start-Process "http://127.0.0.1:9630/health" })
$tray.ShowBalloonTip(4000, "LYGO BUILDR", "Daemon running on port 9630. Right-click for menu.", [System.Windows.Forms.ToolTipIcon]::Info)
[System.Windows.Forms.Application]::Run()