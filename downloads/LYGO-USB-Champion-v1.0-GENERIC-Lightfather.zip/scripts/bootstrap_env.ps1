# LYGO Builder Key - session env (standalone USB brain on product/models/ollama)
$Key = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Stack = Join-Path $Key "stack\lygo-protocol-stack"
$UsbModels = Join-Path $Key "product\models\ollama"
$env:LYGO_BUILDER_KEY_ROOT = $Key
$env:LYGO_STACK_ROOT = $Stack
$env:OLLAMA_MODELS = $UsbModels
$env:OLLAMA_HOST = if ($env:OLLAMA_HOST) { $env:OLLAMA_HOST } else { "127.0.0.1:11434" }
New-Item -ItemType Directory -Force -Path $UsbModels | Out-Null
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "resolve_ollama.ps1") -Quiet
Write-Host "LYGO_BUILDER_KEY_ROOT=$Key"
Write-Host "LYGO_STACK_ROOT=$Stack"
Write-Host "OLLAMA_MODELS=$UsbModels"
if ($env:LYGO_OLLAMA_EXE) { Write-Host "LYGO_OLLAMA_EXE=$($env:LYGO_OLLAMA_EXE)" }
if (Test-Path $Stack) {
    Set-Location $Stack
    Write-Host "OK stack present"
} else {
    Write-Warning "Stack missing - run bootstrap_from_github.ps1"
}