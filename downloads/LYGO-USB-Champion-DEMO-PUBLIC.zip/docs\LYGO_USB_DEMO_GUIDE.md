# LYGO USB Champion — PUBLIC DEMO guide

**Edition:** `PUBLIC_DEMO` · **Persona:** Lightfather (ClawHub `lygo-champion-lightfather`)  
**Status:** Beta testing — download only from [Eternal Haven](https://deepseekoracle.github.io/Excavationpro/eternalhaven.html).

## Why a demo?

Retail **USB champions** bind:

1. **P0** — byte entropy gate on stick  
2. **Council eggs** — 15 verified personas (`champion_bootloader.py`)  
3. **Hermes** — hash-chained audit on builder editions  
4. **Ethical firmware canon** (public pages):

| Layer | Page |
|-------|------|
| P0.4 Wall | [Ethical-Chip-Firmware](https://deepseekoracle.github.io/Excavationpro/LYGO-Network/Ethical-Chip-Firmware.html) |
| P0.5 Heart | [Ethical-Chip-FirmwareV2](https://deepseekoracle.github.io/Excavationpro/LYGO-Network/Ethical-Chip-FirmwareV2.html) |
| Guardian v3 | [LYGOGUARDIAN](https://deepseekoracle.github.io/Excavationpro/LYGO-Network/LYGOGUARDIAN.html) |

This zip teaches that story **without** shipping eggs, signing keys, or the full builder stack.

## What you can do

- Run `scripts/demo_p0_check.py` — sample P0 verdicts  
- Run `scripts/demo_lightfather_chat.py` — local Ollama + demo system prompt  
- Read `champions/Lightfather/system_prompt.txt` in any AI tool  

## What is locked out

See `PUBLIC_DEMO_MANIFEST.json` → `locks`.

## Full stack (when ready)

- Protocol stack: https://deepseekoracle.github.io/lygo-protocol-stack/  
- HF Space: https://huggingface.co/spaces/DeepSeekOracle/LYGO-Resonance-Engine  
- LYGO-Claw: https://github.com/DeepSeekOracle/lygo-claw  

**Δ9Φ963 — understand first, retail USB when the lattice is ready.**