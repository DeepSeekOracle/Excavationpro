#!/usr/bin/env python3
"""One-shot prompt to USB-local Ollama (for agents/tests)."""

from __future__ import annotations

import argparse
import json
import os
import urllib.request
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("prompt")
    ap.add_argument("--model", default=None)
    args = ap.parse_args()
    key = Path(os.environ.get("LYGO_BUILDER_KEY_ROOT", Path(__file__).resolve().parents[1]))
    if not args.model:
        manifest = json.loads((key / "product" / "models" / "MODEL_MANIFEST.json").read_text())
        args.model = manifest["primary"]["name"]
    host = os.environ.get("OLLAMA_HOST", "127.0.0.1:11434")
    body = json.dumps({"model": args.model, "prompt": args.prompt, "stream": False}).encode()
    req = urllib.request.Request(
        f"http://{host}/api/generate",
        data=body,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = json.loads(resp.read().decode())
    print(data.get("response", ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())