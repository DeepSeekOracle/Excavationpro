@echo off
title LYGO USB - System Check
cd /d "%~dp0.."
echo === LYGO USB system check ===
where python >nul 2>&1
if errorlevel 1 (
  echo [FAIL] Python not on PATH.
  echo Install Python 3.11+ from https://www.python.org/downloads/
  echo Check "Add python.exe to PATH" during install.
  pause
  exit /b 1
)
python --version
if not exist "product\runtime\ollama\ollama.exe" (
  echo [WARN] Portable Ollama not on USB - run FIRST_TIME_SETUP.bat or One-Boot once online.
) else (
  echo [OK] Portable Ollama on USB
)
if not exist "product\models\ollama\blobs" (
  echo [WARN] AI model not on USB - run FIRST_TIME_SETUP.bat online once.
) else (
  echo [OK] AI model on USB
)
echo.
echo If both OK, use LYGO_One_Boot_AI.bat for chat.
pause