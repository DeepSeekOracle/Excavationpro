# Resolve LYGO BUILDR USB root (folder containing verify_bootstrap.py + phase2/buildr_usb_daemon.py)
param([string[]]$ExtraSearchRoots = @())

function Find-LygoUsbRoot {
    $markers = @("verify_bootstrap.py", "phase2\buildr_usb_daemon.py")
    $roots = @()
    if ($env:LYGO_BUILDER_KEY_ROOT -and (Test-Path $env:LYGO_BUILDER_KEY_ROOT)) {
        $roots += $env:LYGO_BUILDER_KEY_ROOT
    }
    foreach ($r in $ExtraSearchRoots) { if ($r) { $roots += $r } }
    foreach ($letter in "DEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray()) {
        $roots += "${letter}:\LYGO_BUILDER_KEY"
        $roots += "${letter}:\"
    }
    $seen = @{}
    foreach ($root in $roots | Select-Object -Unique) {
        if (-not $root -or $seen[$root]) { continue }
        $seen[$root] = $true
        $p = $root.TrimEnd('\')
        if (-not (Test-Path $p)) { continue }
        $ok = $true
        foreach ($m in $markers) {
            if (-not (Test-Path (Join-Path $p $m))) { $ok = $false; break }
        }
        if ($ok) { return (Resolve-Path $p).Path }
    }
    return $null
}

Find-LygoUsbRoot