@echo off
title LYGO BUILDR Daemon Tray
cd /d "%~dp0.."
powershell -ExecutionPolicy Bypass -File launchers\daemon_tray.ps1
pause