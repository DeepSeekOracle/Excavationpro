$ErrorActionPreference = "SilentlyContinue"
. (Join-Path $PSScriptRoot "bootstrap_env.ps1")
. (Join-Path $PSScriptRoot "resolve_ollama.ps1") -Quiet
if (-not $env:LYGO_OLLAMA_EXE) { Write-Error "No ollama.exe - run scripts\bundle_ollama_to_usb.ps1"; exit 1 }
$hostAddr = $env:OLLAMA_HOST
if (-not $hostAddr) { $hostAddr = "127.0.0.1:11434" }
try {
    Invoke-RestMethod -Uri "http://$hostAddr/api/tags" -TimeoutSec 2 | Out-Null
    return
} catch {}
Get-Process -Name "ollama" -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2
Write-Host "Starting USB Ollama serve ($($env:LYGO_OLLAMA_EXE))"
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $env:LYGO_OLLAMA_EXE
$psi.Arguments = "serve"
$psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
$psi.UseShellExecute = $false
$psi.Environment["OLLAMA_MODELS"] = $env:OLLAMA_MODELS
$psi.Environment["OLLAMA_HOST"] = $env:OLLAMA_HOST
if (-not $env:OLLAMA_KEEP_ALIVE) { $psi.Environment["OLLAMA_KEEP_ALIVE"] = "15m" }
if (-not $env:OLLAMA_NUM_PARALLEL) { $psi.Environment["OLLAMA_NUM_PARALLEL"] = "1" }
[System.Diagnostics.Process]::Start($psi) | Out-Null
Start-Sleep -Seconds 4