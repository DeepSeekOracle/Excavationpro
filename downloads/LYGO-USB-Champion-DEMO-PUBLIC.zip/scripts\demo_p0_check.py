#!/usr/bin/env python3
"""PUBLIC_DEMO — run P0 sample on demo text (educational only)."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "p0"))

import byte_entropy_filter as p0  # noqa: E402

SAMPLES = [
    b"Hello LYGO demo — honest P0 entropy check.",
    b"\x00\x00\x00\xff" * 200,
]


def main() -> int:
    results = []
    for data in SAMPLES:
        r = p0.validate_bytes(data[:8192])
        results.append({"len": len(data), "decision": r.get("decision"), "phi_risk": r.get("phi_risk")})
    print(json.dumps({"signature": "D9Phi963-DEMO-P0-v1", "samples": results}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())