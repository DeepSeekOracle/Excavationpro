@echo off
title LYGO Supervisor Daemon :9630
cd /d "%~dp0.."
set LYGO_BUILDER_KEY_ROOT=%CD%
set LYGO_STACK_ROOT=%CD%\stack\lygo-protocol-stack
python phase2\init_data_partition.py
python verify_bootstrap.py --phase2
echo Same daemon as LYGO_BUILDR_Daemon.bat (supervisor + tasks).
python phase2\buildr_usb_daemon.py --key-root %CD%
pause