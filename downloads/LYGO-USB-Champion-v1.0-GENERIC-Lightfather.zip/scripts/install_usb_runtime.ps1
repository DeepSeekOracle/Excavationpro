# Install Ollama runtime on a machine with no AI (one-time, online)
$ErrorActionPreference = "Stop"
if (Get-Command ollama -ErrorAction SilentlyContinue) {
    Write-Host "OK ollama already on PATH: $(ollama --version 2>&1)"
    exit 0
}
Write-Host "Ollama not found. Installing via winget..."
$winget = Get-Command winget -ErrorAction SilentlyContinue
if (-not $winget) {
    Write-Host "Install Ollama manually: https://ollama.com/download/windows"
    Write-Host "Then re-run scripts\hydrate_usb_models.ps1"
    exit 1
}
winget install --id Ollama.Ollama -e --accept-source-agreements --accept-package-agreements
Write-Host "Restart terminal if needed, then: scripts\hydrate_usb_models.ps1"