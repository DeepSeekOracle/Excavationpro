#!/usr/bin/env python3
"""Ensure PUBLIC_DEMO tree has no forbidden builder artifacts."""

from __future__ import annotations

import json
import re
from pathlib import Path

FORBIDDEN = ("_builder_vault", "core_signing.key", ".bin", "lygo_core.tar.gz")
SECRET = re.compile(r"(sk-[a-zA-Z0-9]{20,}|ghp_[a-zA-Z0-9]{20,})")
REQUIRED = (
    "PUBLIC_DEMO_MANIFEST.json",
    "README_DEMO_LOCKED.txt",
    "champions/Lightfather/system_prompt.txt",
    "docs/LYGO_USB_DEMO_GUIDE.md",
)


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    hits = []
    for f in root.rglob("*"):
        if not f.is_file():
            continue
        rel = f.relative_to(root).as_posix()
        if any(x in rel for x in FORBIDDEN):
            hits.append(f"forbidden:{rel}")
        try:
            t = f.read_text(encoding="utf-8", errors="ignore")[:30000]
            if SECRET.search(t):
                hits.append(f"secret_pattern:{rel}")
        except OSError:
            pass
    missing = [r for r in REQUIRED if not (root / r).is_file()]
    manifest = json.loads((root / "PUBLIC_DEMO_MANIFEST.json").read_text(encoding="utf-8-sig"))
    ok = manifest.get("demo_locked") is True and not hits and not missing
    print(json.dumps({"ok": ok, "hits": hits[:20], "missing": missing, "edition": manifest.get("edition")}, indent=2))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())