@echo off
title LYGO BUILDR USB Verify (Phase 2)
cd /d "%~dp0.."
set LYGO_BUILDER_KEY_ROOT=%CD%
set LYGO_STACK_ROOT=%CD%\stack\lygo-protocol-stack
python verify_bootstrap.py --edition GROK_BUILDR --phase2
if errorlevel 1 pause & exit /b 1
echo Phase 2 OK. See verify\bootstrap_last_run.json
pause