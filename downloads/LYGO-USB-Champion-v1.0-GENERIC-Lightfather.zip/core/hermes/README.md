# LYGO Hermes Audit Trail (BUILDR USB)

Hash-chained JSONL log for tool calls, boot, and verify steps.

- **Module:** `lygo_hermes_audit.py`
- **Default log:** `hermes/audit_trail.log` (override `LYGO_HERMES_AUDIT_LOG`)
- **Validate:** `python lygo_hermes_audit.py --validate`

Integrated in `verify_bootstrap.py`. Broken chain → **QUARANTINE** (do not run untrusted tools).

**Δ9Φ963-HERMES**