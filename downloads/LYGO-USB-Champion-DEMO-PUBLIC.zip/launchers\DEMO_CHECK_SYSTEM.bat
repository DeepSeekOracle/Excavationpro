@echo off
setlocal
cd /d "%~dp0.."
echo LYGO USB CHAMPION PUBLIC DEMO - system check
python --version >nul 2>&1 || (echo Install Python 3.11+ from python.org & pause & exit /b 1)
python scripts\verify_demo_edition.py
if errorlevel 1 exit /b 1
python scripts\demo_p0_check.py
echo.
echo Optional: install Ollama from https://ollama.com then ollama pull llama3.2:1b
echo Then run launchers\DEMO_LIGHTFATHER_CHAT.bat
pause