# Start BUILDR USB daemon (hidden-friendly, no pause)
param(
    [Parameter(Mandatory = $true)][string]$KeyRoot,
    [switch]$WithOllama
)

$ErrorActionPreference = "Stop"
Set-Location $KeyRoot
$env:LYGO_BUILDER_KEY_ROOT = $KeyRoot
$env:LYGO_STACK_ROOT = Join-Path $KeyRoot "stack\lygo-protocol-stack"
& (Join-Path $KeyRoot "scripts\bootstrap_env.ps1") | Out-Null
python (Join-Path $KeyRoot "phase2\init_data_partition.py") | Out-Null
$args = @(
    (Join-Path $KeyRoot "phase2\buildr_usb_daemon.py"),
    "--key-root", $KeyRoot
)
if ($WithOllama) { $args += "--with-ollama" }
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = "python"
$psi.Arguments = ($args -join " ")
$psi.WorkingDirectory = $KeyRoot
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
# Child inherits current session env (bootstrap_env.ps1 already set OLLAMA_* etc.)
$proc = [System.Diagnostics.Process]::Start($psi)
$pidFile = Join-Path $KeyRoot "data\user_data\buildr_daemon.pid"
New-Item -ItemType Directory -Force -Path (Split-Path $pidFile) | Out-Null
Set-Content -Path $pidFile -Value $proc.Id -Encoding ascii
return $proc