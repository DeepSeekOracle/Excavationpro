#!/usr/bin/env python3
"""USB Champions at core level — retail SKU ↔ verified council eggs ↔ P0/Guardian firmware chain."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

SIGNATURE = "D9Phi963-USB-CHAMPIONS-CORE-v1"


def key_root() -> Path:
    env = os.environ.get("LYGO_BUILDER_KEY_ROOT")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parents[1]
    if (here / "BUILDER_MANIFEST.json").is_file():
        return here
    raise SystemExit("Set LYGO_BUILDER_KEY_ROOT or run from USB key root")


def load_core_manifest(root: Path) -> dict:
    path = root / "config" / "USB_CHAMPIONS_CORE.json"
    if not path.is_file():
        raise FileNotFoundError(path)
    return json.loads(path.read_text(encoding="utf-8"))


def stack_root(root: Path, manifest: dict) -> Path:
    rel = manifest.get("core_stack_relative", "stack/lygo-protocol-stack")
    return root / rel


def verify_council(root: Path, manifest: dict) -> dict:
    stack = stack_root(root, manifest)
    verify_py = stack / "tools" / "verify_champion_eggs.py"
    if not verify_py.is_file():
        return {"ok": False, "error": "missing verify_champion_eggs.py on stick stack"}
    proc = subprocess.run(
        [sys.executable, str(verify_py)],
        cwd=str(stack),
        capture_output=True,
        text=True,
        timeout=120,
    )
    out_path = stack / "tests" / "champion_eggs_last_run.json"
    if not out_path.is_file():
        out_path = root / "verify" / "champion_eggs_last_run.json"
    verdict = None
    if out_path.is_file():
        verdict = json.loads(out_path.read_text(encoding="utf-8"))
    ok = proc.returncode == 0 and (verdict or {}).get("verdict") == "ALIGNED"
    return {
        "ok": ok,
        "exit_code": proc.returncode,
        "verdict": (verdict or {}).get("verdict"),
        "council_merkle_root": (verdict or {}).get("council_merkle_root"),
    }


def boot_egg(root: Path, manifest: dict, egg_id: str) -> dict:
    stack = stack_root(root, manifest)
    boot_py = stack / "tools" / "champion_bootloader.py"
    if not boot_py.is_file():
        raise FileNotFoundError(boot_py)
    proc = subprocess.run(
        [sys.executable, str(boot_py), "--egg", egg_id],
        cwd=str(stack),
        capture_output=True,
        text=True,
        timeout=120,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr or proc.stdout or "bootloader failed")
    return json.loads(proc.stdout)


def resolve_retail(root: Path, manifest: dict, sku: str) -> dict:
    skus = manifest.get("retail_skus") or {}
    if sku not in skus:
        raise KeyError(f"unknown retail SKU: {sku}")
    entry = dict(skus[sku])
    entry["sku"] = sku
    entry["firmware_chain"] = manifest.get("ethical_firmware_chain")
    prompt_rel = entry.get("prompt_path")
    if prompt_rel:
        p = root / prompt_rel
        if p.is_file():
            entry["retail_prompt_sha256_prefix"] = _sha_prefix(p.read_bytes())
    if manifest.get("verify_before_boot"):
        v = verify_council(root, manifest)
        entry["council_verify"] = v
        if not v.get("ok"):
            entry["boot_status"] = "QUARANTINE"
            return entry
    payload = boot_egg(root, manifest, entry["egg_id"])
    entry["boot_status"] = "READY"
    entry["boot_payload"] = {
        "egg_id": payload.get("egg_id"),
        "champion_id": payload.get("champion_id"),
        "merkle_root": payload.get("merkle_root"),
        "ethical_gates": payload.get("ethical_gates"),
        "protocol_layers": payload.get("protocol_layers"),
        "prompt_chars": len(payload.get("system_prompt") or ""),
    }
    return entry


def _sha_prefix(data: bytes, n: int = 16) -> str:
    import hashlib

    return hashlib.sha256(data).hexdigest()[:n]


def cmd_verify_all(root: Path) -> int:
    manifest = load_core_manifest(root)
    council = verify_council(root, manifest)
    skus = manifest.get("retail_skus") or {}
    sku_results = {}
    for name, spec in skus.items():
        egg_id = spec.get("egg_id")
        reg = stack_root(root, manifest) / "data" / "champion_eggs" / "registry.json"
        in_registry = False
        if reg.is_file():
            reg_data = json.loads(reg.read_text(encoding="utf-8"))
            in_registry = any(e.get("egg_id") == egg_id for e in reg_data.get("eggs", []))
        sku_results[name] = {
            "egg_id": egg_id,
            "in_registry": in_registry,
            "prompt_exists": (root / spec.get("prompt_path", "")).is_file(),
        }
    report = {
        "signature": SIGNATURE,
        "ok": council.get("ok") and all(s["in_registry"] and s["prompt_exists"] for s in sku_results.values()),
        "firmware_chain": list((manifest.get("ethical_firmware_chain") or {}).keys()),
        "council_verify": council,
        "retail_skus": sku_results,
    }
    print(json.dumps(report, indent=2))
    return 0 if report["ok"] else 1


def main() -> int:
    ap = argparse.ArgumentParser(description="USB Champions core — council eggs + Guardian firmware chain")
    ap.add_argument("--verify-all", action="store_true", help="verify 15 council + 4 retail SKU wiring")
    ap.add_argument("--boot", metavar="SKU", help="boot retail SKU via champion_bootloader (Lightfather, LYRA, ...)")
    ap.add_argument("--list", action="store_true", help="list retail SKUs and egg_ids")
    args = ap.parse_args()
    root = key_root()
    manifest = load_core_manifest(root)

    if args.list:
        for name, spec in (manifest.get("retail_skus") or {}).items():
            print(f"{name}\t{spec.get('egg_id')}\t{spec.get('council_id')}")
        return 0
    if args.verify_all:
        return cmd_verify_all(root)
    if args.boot:
        try:
            print(json.dumps(resolve_retail(root, manifest, args.boot), indent=2, ensure_ascii=False))
            return 0
        except Exception as exc:  # noqa: BLE001
            print(json.dumps({"ok": False, "error": str(exc), "signature": SIGNATURE}), indent=2)
            return 1
    ap.print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())