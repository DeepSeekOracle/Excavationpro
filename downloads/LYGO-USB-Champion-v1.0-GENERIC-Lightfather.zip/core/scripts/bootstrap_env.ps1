# LYGO Builder Key — set env for this session (any AI / human)
$Key = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Stack = Join-Path $Key "stack\lygo-protocol-stack"
$env:LYGO_BUILDER_KEY_ROOT = $Key
$env:LYGO_STACK_ROOT = $Stack
Write-Host "LYGO_BUILDER_KEY_ROOT=$Key"
Write-Host "LYGO_STACK_ROOT=$Stack"
if (Test-Path $Stack) {
  Set-Location $Stack
  Write-Host "OK stack present"
} else {
  Write-Warning "Stack missing — run bootstrap_from_github.ps1"
}
