================================================================================
LYGO USB CHAMPION — PUBLIC DEMO (LOCKED) — Lightfather Architect
================================================================================
Signature: D9Phi963-USB-CHAMPION-DEMO-v1
Status: BETA — we are still testing. NOT the full retail USB product.

WHAT THIS IS
  A small, legal demo you can copy onto any USB stick to LEARN how LYGO USB
  champions work: P0 gate sample, Lightfather advisor persona (ClawHub skill
  aligned), and optional local chat via YOUR Ollama install.

WHAT THIS IS NOT (DEMO LOCK)
  - No kernel eggs, champion egg binaries, or signing keys
  - No full lygo-protocol-stack tree or builder daemon secrets
  - No pre-bundled multi-GB Ollama runtime (you pull a model yourself)
  - Not licensed for resale or repackaging as a competing product

DOWNLOAD SOURCE (required)
  Get updates only from Eternal Haven hub:
  https://deepseekoracle.github.io/Excavationpro/eternalhaven.html

QUICK START (Windows)
  1. Copy this entire folder to your USB (e.g. E:\LYGO_USB_DEMO)
  2. launchers\DEMO_CHECK_SYSTEM.bat
  3. Install Ollama from https://ollama.com then: ollama pull llama3.2:1b
  4. launchers\DEMO_LIGHTFATHER_CHAT.bat

Persona skill (full advisor pack on ClawHub):
  npx clawhub@latest install deepseekoracle/lygo-champion-lightfather

Support / full stack docs:
  https://deepseekoracle.github.io/lygo-protocol-stack/

================================================================================