@echo off
title LYGO Install Daemon Autostart
cd /d "%~dp0"
echo Opt-in: tray + daemon at Windows logon (when USB is plugged in).
echo.
set /p OLLAMA=Also start USB Ollama with daemon? [y/N]:
if /i "%OLLAMA%"=="y" (
  powershell -ExecutionPolicy Bypass -File install_buildr_autostart.ps1 -WithOllama
) else (
  powershell -ExecutionPolicy Bypass -File install_buildr_autostart.ps1
)
pause